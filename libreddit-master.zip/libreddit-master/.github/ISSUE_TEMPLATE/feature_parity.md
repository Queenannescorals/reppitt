---
name: ✨ Feature parity
about: Suggest implementing a feature into Libreddit that is found in Reddit.com
title: '✨ Feature parity: '
labels: feature parity
assignees: ''

---

## How does this feature work on Reddit?
<!--
  A clear and concise description of what the feature is.
-->

## Describe how this could be implemented into Libreddit
<!--
  A clear and concise description of what you want to happen.
-->

## Describe alternatives you've considered
<!--
  A clear and concise description of any alternative solutions or features you've considered.
-->

## Additional context / screenshot
<!--
  Add any other context or screenshots about the feature parity request here.
-->
